import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * JCZXT 背包 —— Java 版
 * 对应 Python: JCZXT_bag.py
 */
public class JCZXT_bag extends JFrame {

    private static final String BAG_FILE = "JCZXT_bag_thing.json";
    private JPanel content;

    public JCZXT_bag() {
        setTitle("JCZXT 背包");
        setSize(600, 500);
        setMinimumSize(new Dimension(460, 360));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.decode("#f3f5f7"));

        // ===== 顶部栏 =====
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.decode("#202b36"));

        JLabel titleLabel = new JLabel("我的背包");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        header.add(titleLabel, BorderLayout.WEST);

        JButton refreshBtn = createButton("刷新", "#2a9d8f", "#21867b");
        refreshBtn.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 12));
        refreshBtn.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        refreshBtn.addActionListener(e -> refresh());
        JPanel btnWrap = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 14));
        btnWrap.setOpaque(false);
        btnWrap.add(refreshBtn);
        header.add(btnWrap, BorderLayout.EAST);

        root.add(header, BorderLayout.NORTH);

        // ===== 内容区（滚动） =====
        content = new JPanel();
        content.setBackground(Color.decode("#f3f5f7"));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        scroll.getViewport().setBackground(Color.decode("#f3f5f7"));
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        root.add(scroll, BorderLayout.CENTER);

        setContentPane(root);
        refresh();
    }

    // ===== 数据 =====
    @SuppressWarnings("unchecked")
    private Map<String, Object> loadBag() {
        File f = new File(BAG_FILE);
        if (!f.exists()) {
            try {
                SimpleJson.writeFile(BAG_FILE, new LinkedHashMap<>());
            } catch (IOException ignored) {}
            return new LinkedHashMap<>();
        }
        try {
            Object obj = SimpleJson.readFile(BAG_FILE);
            if (obj instanceof Map) return (Map<String, Object>) obj;
            return new LinkedHashMap<>();
        } catch (Exception e) {
            return new LinkedHashMap<>();
        }
    }

    private void refresh() {
        content.removeAll();
        Map<String, Object> bag = loadBag();

        if (bag.isEmpty()) {
            JLabel empty = new JLabel("背包还是空的");
            empty.setAlignmentX(Component.CENTER_ALIGNMENT);
            empty.setForeground(Color.decode("#52616b"));
            empty.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));
            content.add(Box.createVerticalGlue());
            content.add(empty);
            content.add(Box.createVerticalGlue());
        } else {
            for (Map.Entry<String, Object> entry : bag.entrySet()) {
                content.add(createItemRow(entry.getKey(), entry.getValue()));
                content.add(Box.createVerticalStrut(5));
            }
            content.add(Box.createVerticalGlue());
        }
        content.revalidate();
        content.repaint();
    }

    private JPanel createItemRow(String name, Object quantity) {
        JPanel row = new JPanel(new BorderLayout());
        row.setBackground(Color.WHITE);
        row.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.decode("#dce2e7"), 1),
                BorderFactory.createEmptyBorder(13, 16, 13, 16)
        ));
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));

        JLabel nameLabel = new JLabel(name);
        nameLabel.setForeground(Color.decode("#202b36"));
        nameLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 13));
        row.add(nameLabel, BorderLayout.WEST);

        JLabel qtyLabel = new JLabel("数量：" + quantity);
        qtyLabel.setForeground(Color.decode("#2a9d8f"));
        qtyLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 12));
        row.add(qtyLabel, BorderLayout.EAST);

        return row;
    }

    // ===== 工具 =====
    private static JButton createButton(String text, String bgHex, String activeHex) {
        JButton btn = new JButton(text);
        btn.setBackground(Color.decode(bgHex));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setOpaque(true);
        // 鼠标悬停效果
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode(activeHex));
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode(bgHex));
            }
        });
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JCZXT_bag app = new JCZXT_bag();
            app.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            app.setVisible(true);
        });
    }
}
