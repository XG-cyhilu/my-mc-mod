import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * JCZXT 商店 —— Java 版
 * 对应 Python: JCZXTshop.py
 */
public class JCZXTshop extends JFrame {

    private static final String DATA_FILE = "JCZXT_M.json";
    private static final String BAG_FILE = "JCZXT_bag_thing.json";
    private static final int MAX_DETECTABLE_M = 1048576;

    private Map<String, Object> data;
    private JLabel balanceLabel;
    private JPanel categoryBar;
    private JPanel content;
    private String currentCategory;

    public JCZXTshop() {
        this.data = loadData();

        if (SimpleJson.asInt(data.get("M币"), 0) > MAX_DETECTABLE_M) {
            JOptionPane.showMessageDialog(null, "M币无法检测，暂时不能使用商店。",
                    "商店不可用", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        setTitle("JCZXT 商店");
        setSize(900, 620);
        setMinimumSize(new Dimension(700, 480));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.decode("#f3f5f7"));

        // ===== 顶部栏 =====
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(Color.decode("#202b36"));

        JLabel titleLabel = new JLabel("JCZXT 商店");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        top.add(titleLabel, BorderLayout.WEST);

        balanceLabel = new JLabel();
        balanceLabel.setForeground(Color.decode("#ffd166"));
        balanceLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 14));
        balanceLabel.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        top.add(balanceLabel, BorderLayout.EAST);

        root.add(top, BorderLayout.NORTH);

        // ===== 分类栏 =====
        categoryBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        categoryBar.setBackground(Color.WHITE);
        root.add(categoryBar, BorderLayout.CENTER);

        // 临时占位，实际在 showCategory 中填充
        // 用一个包装面板放分类栏+内容
        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(Color.decode("#f3f5f7"));
        centerPanel.add(categoryBar, BorderLayout.NORTH);

        // ===== 内容区 =====
        content = new JPanel();
        content.setBackground(Color.decode("#f3f5f7"));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));
        scroll.getViewport().setBackground(Color.decode("#f3f5f7"));
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        centerPanel.add(scroll, BorderLayout.CENTER);

        root.add(centerPanel, BorderLayout.CENTER);
        setContentPane(root);

        // 显示第一个分类
        Map<String, Object> items = SimpleJson.asMap(data.get("物品"));
        if (!items.isEmpty()) {
            currentCategory = items.keySet().iterator().next();
            showCategory(currentCategory);
        }
    }

    // ===== 默认数据 =====
    @SuppressWarnings("unchecked")
    private static Map<String, Object> defaultData() {
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("M币", 1000);

        Map<String, Object> categories = new LinkedHashMap<>();

        // 近战
        List<Object> melee = new ArrayList<>();
        melee.add(item("木棍", 1, 1, 1, null));
        melee.add(item("砖头", 2, 1, 3, null));
        melee.add(item("小刀", 5, 1, 10, null));
        melee.add(item("匕首", 6, 1, 15, null));
        melee.add(item("砍刀", 10, 2, 25, null));
        melee.add(item("长刀", 12, 2, 30, null));
        melee.add(item("剑", 15, 2, 45, null));
        melee.add(item("长剑", 15, 3, 50, null));
        melee.add(item("帝国之刃", 20, 3, 100, null));
        melee.add(item("帝国之剑", 30, 3, 120, null));
        melee.add(item("帝国光辉之刃", 50, 3, 200, null));
        melee.add(item("帝国光辉之剑", 80, 3, 300, null));
        melee.add(item("荣光", 180, 5, 1000, "荣光？这代表了什么？"));
        categories.put("近战", melee);

        // 远程
        List<Object> ranged = new ArrayList<>();
        ranged.add(item("手枪", 5, 5, 25, null));
        ranged.add(item("增强手枪", 6, 8, 35, null));
        ranged.add(ammoItem("手枪子弹*10", 10, "用于手枪和增强手枪的子弹"));
        ranged.add(item("步枪", 8, 15, 60, null));
        ranged.add(item("增强步枪", 10, 18, 80, null));
        ranged.add(ammoItem("步枪子弹*8", 20, "用于步枪和增强步枪的子弹"));
        ranged.add(item("狙击枪", 15, 25, 120, null));
        ranged.add(ammoItem("狙击枪子弹*5", 40, "用于狙击枪的子弹"));
        ranged.add(item("帝国之光", 50, 40, 750, "光？为何这么说呢？"));
        ranged.add(item("传承", 200, 80, 2000, "传承吗"));
        categories.put("远程", ranged);

        // 医疗
        List<Object> medical = new ArrayList<>();
        medical.add(item("创可贴", -5, 0, 20, "只能对自己使用"));
        medical.add(item("绷带", -8, 0, 40, null));
        medical.add(item("药品", -15, 0, 80, null));
        medical.add(item("神奇的药品", -50, 0, 350, null));
        medical.add(item("辉", -150, 0, 1200, "辉？是余晖？不、是光辉"));
        categories.put("医疗", medical);

        data.put("物品", categories);
        return data;
    }

    private static Map<String, Object> item(String name, int damage, int distance, int price, String desc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("名称", name);
        m.put("伤害", damage);
        m.put("距离", distance);
        m.put("价格", price);
        if (desc != null) m.put("简介", desc);
        return m;
    }

    private static Map<String, Object> ammoItem(String name, int price, String desc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("名称", name);
        m.put("价格", price);
        if (desc != null) m.put("简介", desc);
        return m;
    }

    // ===== 数据读写 =====
    @SuppressWarnings("unchecked")
    private Map<String, Object> loadData() {
        File f = new File(DATA_FILE);
        if (!f.exists()) {
            try {
                SimpleJson.writeFile(DATA_FILE, defaultData());
            } catch (IOException ignored) {}
            return defaultData();
        }
        try {
            Object obj = SimpleJson.readFile(DATA_FILE);
            if (!(obj instanceof Map)) return defaultData();
            Map<String, Object> d = (Map<String, Object>) obj;
            if (!d.containsKey("M币")) d.put("M币", 1000);
            if (!d.containsKey("物品")) d.put("物品", defaultData().get("物品"));
            return d;
        } catch (Exception e) {
            return defaultData();
        }
    }

    @SuppressWarnings("unchecked")
    private void addToBag(String itemName) {
        Map<String, Object> bag;
        File f = new File(BAG_FILE);
        try {
            if (f.exists()) {
                Object obj = SimpleJson.readFile(BAG_FILE);
                bag = obj instanceof Map ? (Map<String, Object>) obj : new LinkedHashMap<>();
            } else {
                bag = new LinkedHashMap<>();
            }
            int current = SimpleJson.asInt(bag.get(itemName), 0);
            bag.put(itemName, current + 1);
            SimpleJson.writeFile(BAG_FILE, bag);
        } catch (Exception e) {
            try {
                Map<String, Object> fresh = new LinkedHashMap<>();
                fresh.put(itemName, 1);
                SimpleJson.writeFile(BAG_FILE, fresh);
            } catch (IOException ignored) {}
        }
    }

    // ===== UI =====
    private void updateBalance() {
        balanceLabel.setText("M币：" + data.get("M币"));
    }

    @SuppressWarnings("unchecked")
    private void showCategory(String category) {
        currentCategory = category;
        categoryBar.removeAll();

        Map<String, Object> items = SimpleJson.asMap(data.get("物品"));
        for (String name : items.keySet()) {
            JButton catBtn = new JButton(name);
            catBtn.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 11));
            catBtn.setFocusPainted(false);
            catBtn.setBorderPainted(false);
            catBtn.setContentAreaFilled(true);
            catBtn.setOpaque(true);
            catBtn.setBorder(BorderFactory.createEmptyBorder(10, 22, 10, 22));
            if (name.equals(category)) {
                catBtn.setBackground(Color.decode("#e6eef5"));
                catBtn.setForeground(Color.decode("#202b36"));
            } else {
                catBtn.setBackground(Color.WHITE);
                catBtn.setForeground(Color.decode("#52616b"));
                catBtn.addMouseListener(new java.awt.event.MouseAdapter() {
                    @Override
                    public void mouseEntered(java.awt.event.MouseEvent e) {
                        catBtn.setBackground(Color.decode("#e6eef5"));
                    }
                    @Override
                    public void mouseExited(java.awt.event.MouseEvent e) {
                        catBtn.setBackground(Color.WHITE);
                    }
                });
            }
            catBtn.addActionListener(e -> showCategory(name));
            categoryBar.add(catBtn);
        }
        categoryBar.revalidate();
        categoryBar.repaint();

        // 内容
        content.removeAll();

        JLabel sectionTitle = new JLabel(category + " · 购买页面");
        sectionTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        sectionTitle.setForeground(Color.decode("#202b36"));
        sectionTitle.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 17));
        sectionTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));
        content.add(sectionTitle);

        List<Object> categoryItems = SimpleJson.asList(items.get(category));
        for (Object itemObj : categoryItems) {
            content.add(createItemCard(SimpleJson.asMap(itemObj)));
            content.add(Box.createVerticalStrut(5));
        }
        content.add(Box.createVerticalGlue());

        content.revalidate();
        content.repaint();
        updateBalance();
    }

    private JPanel createItemCard(Map<String, Object> item) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.decode("#dce2e7"), 1),
                BorderFactory.createEmptyBorder(12, 14, 12, 14)
        ));
        card.setMaximumSize(new Dimension(Integer.MAX_VALUE, 60));

        // 名称
        JLabel nameLabel = new JLabel(SimpleJson.asString(item.get("名称"), ""));
        nameLabel.setForeground(Color.decode("#202b36"));
        nameLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 13));
        nameLabel.setPreferredSize(new Dimension(140, 30));
        nameLabel.setHorizontalAlignment(SwingConstants.LEFT);

        // 详情
        StringBuilder details = new StringBuilder();
        if (item.containsKey("伤害")) {
            int dmg = SimpleJson.asInt(item.get("伤害"), 0);
            String type = dmg < 0 ? "回血" : "伤害";
            details.append(type).append("：").append(Math.abs(dmg))
                    .append("　距离：").append(SimpleJson.asInt(item.get("距离"), 0));
        } else {
            details.append("弹药");
        }
        JLabel detailsLabel = new JLabel(details.toString());
        detailsLabel.setForeground(Color.decode("#52616b"));
        detailsLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 12));

        // 简介
        JLabel descLabel = new JLabel(SimpleJson.asString(item.get("简介"), "暂无简介"));
        descLabel.setForeground(Color.decode("#7a8791"));
        descLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 11));
        descLabel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));

        JPanel leftPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        leftPanel.setOpaque(false);
        leftPanel.add(nameLabel);
        leftPanel.add(detailsLabel);
        leftPanel.add(descLabel);

        // 购买按钮
        JButton buyBtn = new JButton("<html><center>" + item.get("价格") + " M币<br>购买</center></html>");
        buyBtn.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 10));
        buyBtn.setBackground(Color.decode("#2a9d8f"));
        buyBtn.setForeground(Color.WHITE);
        buyBtn.setFocusPainted(false);
        buyBtn.setBorderPainted(false);
        buyBtn.setContentAreaFilled(true);
        buyBtn.setOpaque(true);
        buyBtn.setPreferredSize(new Dimension(90, 44));
        buyBtn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                buyBtn.setBackground(Color.decode("#21867b"));
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                buyBtn.setBackground(Color.decode("#2a9d8f"));
            }
        });
        buyBtn.addActionListener(e -> buy(item));

        card.add(leftPanel, BorderLayout.CENTER);
        card.add(buyBtn, BorderLayout.EAST);
        return card;
    }

    private void buy(Map<String, Object> item) {
        int price = SimpleJson.asInt(item.get("价格"), 0);
        int balance = SimpleJson.asInt(data.get("M币"), 0);

        if (balance < price) {
            JOptionPane.showMessageDialog(this, "M币不足。", "购买失败", JOptionPane.ERROR_MESSAGE);
            return;
        }

        data.put("M币", balance - price);
        try {
            SimpleJson.writeFile(DATA_FILE, data);
        } catch (IOException ignored) {}

        addToBag(SimpleJson.asString(item.get("名称"), ""));
        updateBalance();
        JOptionPane.showMessageDialog(this, "已购买：" + item.get("名称"), "购买成功", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JCZXTshop app = new JCZXTshop();
            app.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            app.setVisible(true);
        });
    }
}
