import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 轻量 JSON 解析/序列化工具，无第三方依赖。
 * 支持对象、数组、字符串、数字、布尔、null。
 */
public class SimpleJson {

    // ==================== 解析 ====================

    public static Object parse(String json) {
        Parser p = new Parser(json);
        p.skipWs();
        Object v = p.parseValue();
        p.skipWs();
        return v;
    }

    private static class Parser {
        final String s;
        int i;

        Parser(String s) {
            this.s = s;
            this.i = 0;
        }

        void skipWs() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }

        Object parseValue() {
            skipWs();
            if (i >= s.length()) return null;
            char c = s.charAt(i);
            if (c == '{') return parseObject();
            if (c == '[') return parseArray();
            if (c == '"') return parseString();
            if (c == 't' || c == 'f') return parseBool();
            if (c == 'n') return parseNull();
            return parseNumber();
        }

        Map<String, Object> parseObject() {
            Map<String, Object> map = new LinkedHashMap<>();
            i++; // {
            skipWs();
            if (i < s.length() && s.charAt(i) == '}') {
                i++;
                return map;
            }
            while (i < s.length()) {
                skipWs();
                String key = parseString();
                skipWs();
                if (i < s.length() && s.charAt(i) == ':') i++;
                Object val = parseValue();
                map.put(key, val);
                skipWs();
                if (i < s.length() && s.charAt(i) == ',') {
                    i++;
                    continue;
                }
                if (i < s.length() && s.charAt(i) == '}') {
                    i++;
                    break;
                }
                break;
            }
            return map;
        }

        List<Object> parseArray() {
            List<Object> list = new ArrayList<>();
            i++; // [
            skipWs();
            if (i < s.length() && s.charAt(i) == ']') {
                i++;
                return list;
            }
            while (i < s.length()) {
                Object val = parseValue();
                list.add(val);
                skipWs();
                if (i < s.length() && s.charAt(i) == ',') {
                    i++;
                    continue;
                }
                if (i < s.length() && s.charAt(i) == ']') {
                    i++;
                    break;
                }
                break;
            }
            return list;
        }

        String parseString() {
            StringBuilder sb = new StringBuilder();
            i++; // "
            while (i < s.length()) {
                char c = s.charAt(i);
                if (c == '"') {
                    i++;
                    break;
                }
                if (c == '\\' && i + 1 < s.length()) {
                    char next = s.charAt(i + 1);
                    switch (next) {
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/': sb.append('/'); break;
                        case 'n': sb.append('\n'); break;
                        case 't': sb.append('\t'); break;
                        case 'r': sb.append('\r'); break;
                        case 'b': sb.append('\b'); break;
                        case 'f': sb.append('\f'); break;
                        case 'u':
                            if (i + 5 < s.length()) {
                                String hex = s.substring(i + 2, i + 6);
                                sb.append((char) Integer.parseInt(hex, 16));
                                i += 4;
                            }
                            break;
                        default: sb.append(next);
                    }
                    i += 2;
                } else {
                    sb.append(c);
                    i++;
                }
            }
            return sb.toString();
        }

        Number parseNumber() {
            int start = i;
            if (i < s.length() && (s.charAt(i) == '-' || s.charAt(i) == '+')) i++;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            boolean isDouble = false;
            if (i < s.length() && s.charAt(i) == '.') {
                isDouble = true;
                i++;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            }
            if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
                isDouble = true;
                i++;
                if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
                while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
            }
            String num = s.substring(start, i);
            if (isDouble) return Double.parseDouble(num);
            try {
                return Long.parseLong(num);
            } catch (NumberFormatException e) {
                return Double.parseDouble(num);
            }
        }

        Boolean parseBool() {
            if (s.startsWith("true", i)) {
                i += 4;
                return Boolean.TRUE;
            }
            if (s.startsWith("false", i)) {
                i += 5;
                return Boolean.FALSE;
            }
            i++;
            return Boolean.FALSE;
        }

        Object parseNull() {
            if (s.startsWith("null", i)) {
                i += 4;
            }
            return null;
        }
    }

    // ==================== 序列化 ====================

    public static String toJson(Object obj) {
        StringBuilder sb = new StringBuilder();
        writeValue(sb, obj, 0);
        return sb.toString();
    }

    public static String toJsonPretty(Object obj) {
        StringBuilder sb = new StringBuilder();
        writeValuePretty(sb, obj, 0);
        sb.append('\n');
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void writeValue(StringBuilder sb, Object obj, int indent) {
        if (obj == null) {
            sb.append("null");
        } else if (obj instanceof String) {
            writeString(sb, (String) obj);
        } else if (obj instanceof Number) {
            Number n = (Number) obj;
            if (n instanceof Double || n instanceof Float) {
                double d = n.doubleValue();
                if (d == Math.floor(d) && !Double.isInfinite(d)) {
                    sb.append((long) d);
                } else {
                    sb.append(d);
                }
            } else {
                sb.append(n.toString());
            }
        } else if (obj instanceof Boolean) {
            sb.append(obj.toString());
        } else if (obj instanceof Map) {
            writeObject(sb, (Map<String, Object>) obj, indent, false);
        } else if (obj instanceof List) {
            writeArray(sb, (List<Object>) obj, indent, false);
        } else {
            writeString(sb, obj.toString());
        }
    }

    @SuppressWarnings("unchecked")
    private static void writeValuePretty(StringBuilder sb, Object obj, int indent) {
        if (obj == null) {
            sb.append("null");
        } else if (obj instanceof String) {
            writeString(sb, (String) obj);
        } else if (obj instanceof Number) {
            Number n = (Number) obj;
            if (n instanceof Double || n instanceof Float) {
                double d = n.doubleValue();
                if (d == Math.floor(d) && !Double.isInfinite(d)) {
                    sb.append((long) d);
                } else {
                    sb.append(d);
                }
            } else {
                sb.append(n.toString());
            }
        } else if (obj instanceof Boolean) {
            sb.append(obj.toString());
        } else if (obj instanceof Map) {
            writeObject(sb, (Map<String, Object>) obj, indent, true);
        } else if (obj instanceof List) {
            writeArray(sb, (List<Object>) obj, indent, true);
        } else {
            writeString(sb, obj.toString());
        }
    }

    private static void writeString(StringBuilder sb, String s) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\t': sb.append("\\t"); break;
                case '\r': sb.append("\\r"); break;
                case '\b': sb.append("\\b"); break;
                case '\f': sb.append("\\f"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
    }

    private static void writeObject(StringBuilder sb, Map<String, Object> map, int indent, boolean pretty) {
        if (map.isEmpty()) {
            sb.append("{}");
            return;
        }
        sb.append('{');
        boolean first = true;
        for (Map.Entry<String, Object> e : map.entrySet()) {
            if (!first) sb.append(',');
            first = false;
            if (pretty) {
                sb.append('\n');
                for (int k = 0; k < indent + 1; k++) sb.append("  ");
            }
            writeString(sb, e.getKey());
            sb.append(':');
            if (pretty) sb.append(' ');
            writeValuePretty(sb, e.getValue(), indent + 1);
        }
        if (pretty) {
            sb.append('\n');
            for (int k = 0; k < indent; k++) sb.append("  ");
        }
        sb.append('}');
    }

    private static void writeArray(StringBuilder sb, List<Object> list, int indent, boolean pretty) {
        if (list.isEmpty()) {
            sb.append("[]");
            return;
        }
        sb.append('[');
        boolean first = true;
        for (Object item : list) {
            if (!first) sb.append(',');
            first = false;
            if (pretty) {
                sb.append('\n');
                for (int k = 0; k < indent + 1; k++) sb.append("  ");
            }
            writeValuePretty(sb, item, indent + 1);
        }
        if (pretty) {
            sb.append('\n');
            for (int k = 0; k < indent; k++) sb.append("  ");
        }
        sb.append(']');
    }

    // ==================== 文件读写 ====================

    public static Object readFile(String path) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get(path));
        return parse(new String(bytes, StandardCharsets.UTF_8));
    }

    public static void writeFile(String path, Object obj) throws IOException {
        String json = toJsonPretty(obj);
        Files.write(Paths.get(path), json.getBytes(StandardCharsets.UTF_8));
    }

    // ==================== 便捷取值 ====================

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asMap(Object obj) {
        return obj instanceof Map ? (Map<String, Object>) obj : new LinkedHashMap<>();
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asList(Object obj) {
        return obj instanceof List ? (List<Object>) obj : new ArrayList<>();
    }

    public static int asInt(Object obj, int def) {
        if (obj instanceof Number) return ((Number) obj).intValue();
        if (obj instanceof String) {
            try { return Integer.parseInt((String) obj); } catch (NumberFormatException e) { return def; }
        }
        return def;
    }

    public static String asString(Object obj, String def) {
        return obj == null ? def : obj.toString();
    }
}
