import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

/**
 * JCZXT 简单世界 —— Java 版
 * 对应 Python: JCZXT_world_easy.py
 */
public class JCZXT_world_easy extends JFrame {

    private static final String DATA_FILE = "JCZXT_M.json";
    private static final int COLS = 60;
    private static final int ROWS = 20;
    private static final int CELL = 16;

    private static final Set<Point> BANK_CELLS = new HashSet<>();
    private static final Set<Point> J_CELLS = new HashSet<>();
    private static final Set<Point> T_CELLS = new HashSet<>();
    private static final Set<Point> KEY_AREA = new HashSet<>();
    private static final int[][] DIRECTIONS = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};

    static {
        for (int x = 1; x <= 4; x++) for (int y = 1; y <= 4; y++) BANK_CELLS.add(new Point(x, y));
        for (int x = 6; x <= 7; x++) for (int y = 6; y <= 7; y++) J_CELLS.add(new Point(x, y));
        for (int x = 59; x <= 60; x++) for (int y = 19; y <= 20; y++) T_CELLS.add(new Point(x, y));
        for (int x = 25; x <= 35; x++) for (int y = 5; y <= 15; y++) KEY_AREA.add(new Point(x, y));
    }

    // 游戏状态
    private boolean gameStarted = false;
    private boolean gameOver = false;
    private String turn = "T";
    private int roundNumber = 1;
    private String playerRole = null;
    private Point player = null;
    private Point robot = null;
    private boolean hasKey = false;
    private boolean robotHasKey = false;
    private Set<Point> obstacles = new HashSet<>();
    private Set<Point> secondaryObstacles = new HashSet<>();
    private Point key = null;

    private final Random random = new Random();

    // UI
    private JLabel statusLabel;
    private GameCanvas canvas;
    private JFrame loadingFrame;

    public JCZXT_world_easy() {
        setTitle("JCZXT 简单世界");
        setSize(1100, 620);
        setMinimumSize(new Dimension(760, 500));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.decode("#f3f5f7"));

        // ===== 顶部栏 =====
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(Color.decode("#202b36"));

        JLabel titleLabel = new JLabel("JCZXT简单世界");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 20));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        header.add(titleLabel, BorderLayout.WEST);

        statusLabel = new JLabel("请选择角色");
        statusLabel.setForeground(Color.decode("#ffd166"));
        statusLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 11));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(14, 24, 14, 24));
        header.add(statusLabel, BorderLayout.EAST);

        root.add(header, BorderLayout.NORTH);

        // ===== 角色选择栏 =====
        JPanel choiceBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 14));
        choiceBar.setBackground(Color.decode("#f3f5f7"));
        choiceBar.setBorder(BorderFactory.createEmptyBorder(0, 20, 4, 20));

        JLabel choiceLabel = new JLabel("选择出生位置：");
        choiceLabel.setForeground(Color.decode("#202b36"));
        choiceLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 11));
        choiceBar.add(choiceLabel);

        for (String role : new String[]{"T", "J"}) {
            JButton btn = createGameButton("作为 " + role + " 出生");
            btn.addActionListener(e -> startGame(role));
            choiceBar.add(btn);
        }

        root.add(choiceBar, BorderLayout.NORTH);

        // ===== 地图区域 =====
        JPanel mapArea = new JPanel(new BorderLayout());
        mapArea.setBackground(Color.decode("#f3f5f7"));
        mapArea.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        canvas = new GameCanvas();
        canvas.setPreferredSize(new Dimension(COLS * CELL, ROWS * CELL));
        canvas.setBackground(Color.WHITE);
        canvas.setFocusable(true);

        JScrollPane scrollPane = new JScrollPane(canvas);
        scrollPane.getViewport().setBackground(Color.WHITE);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        mapArea.add(scrollPane, BorderLayout.CENTER);

        root.add(mapArea, BorderLayout.CENTER);
        setContentPane(root);

        // 键盘监听
        canvas.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKey(e);
            }
        });

        // ===== 加载界面 =====
        showLoading();

        // 后台构建世界
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                try { Thread.sleep(300); } catch (InterruptedException ignored) {}
                buildWorld();
                return null;
            }
            @Override
            protected void done() {
                hideLoading();
                canvas.repaint();
            }
        };
        worker.execute();
    }

    // ===== 加载界面 =====
    private void showLoading() {
        loadingFrame = new JFrame();
        loadingFrame.setUndecorated(true);
        loadingFrame.setSize(getWidth(), getHeight());
        loadingFrame.setLocation(getLocation());
        JPanel loadPanel = new JPanel(new GridBagLayout());
        loadPanel.setBackground(Color.decode("#0288D1"));
        JLabel loadLabel = new JLabel("JCZXT简单世界正在加载中");
        loadLabel.setForeground(Color.WHITE);
        loadLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 24));
        loadPanel.add(loadLabel);
        loadingFrame.setContentPane(loadPanel);
        loadingFrame.setVisible(true);
    }

    private void hideLoading() {
        if (loadingFrame != null) {
            loadingFrame.dispose();
            loadingFrame = null;
        }
    }

    // ===== 世界生成 =====
    private void buildWorld() {
        Set<Point> protectedCells = new HashSet<>();
        protectedCells.addAll(BANK_CELLS);
        protectedCells.addAll(J_CELLS);
        protectedCells.addAll(T_CELLS);

        obstacles = new HashSet<>();
        for (int y = 1; y <= ROWS; y++) {
            for (int x = 1; x <= COLS; x++) {
                Point p = new Point(x, y);
                if (!protectedCells.contains(p) && random.nextInt(20) == 0) {
                    obstacles.add(p);
                }
            }
        }

        secondaryObstacles = new HashSet<>();
        for (Point cell : new ArrayList<>(obstacles)) {
            int outcome = random.nextInt(6);
            int count;
            if (outcome == 0) count = 4;
            else if (outcome == 1) count = 0;
            else if (outcome == 2 || outcome == 3) count = 2;
            else count = 3;

            List<Point> neighbors = new ArrayList<>();
            for (Point n : neighbors(cell)) {
                if (!protectedCells.contains(n) && !obstacles.contains(n) && !secondaryObstacles.contains(n)) {
                    neighbors.add(n);
                }
            }
            Collections.shuffle(neighbors, random);
            secondaryObstacles.addAll(neighbors.subList(0, Math.min(count, neighbors.size())));
        }

        Point tStart = randomCell(T_CELLS);
        carvePath(tStart, randomCell(BANK_CELLS));
        key = findKey(tStart);
        carvePath(tStart, key);
        ensureKeyObstacles(tStart);
    }

    private Point findKey(Point start) {
        List<Point> candidates = new ArrayList<>(KEY_AREA);
        Collections.shuffle(candidates, random);

        for (Point candidate : candidates) {
            int obstacleCount = 0;
            for (Point n : neighbors(candidate)) {
                if (obstacles.contains(n)) obstacleCount++;
            }
            if (obstacleCount >= 2 && hasPath(start, candidate)) {
                return candidate;
            }
        }

        Point candidate = candidates.get(random.nextInt(candidates.size()));
        carvePath(start, candidate);
        List<Point> ns = neighbors(candidate);
        for (int i = 0; i < Math.min(2, ns.size()); i++) {
            obstacles.add(ns.get(i));
        }
        return candidate;
    }

    private boolean hasPath(Point start, Point goal) {
        Queue<Point> pending = new LinkedList<>();
        Set<Point> visited = new HashSet<>();
        pending.add(start);
        visited.add(start);

        while (!pending.isEmpty()) {
            Point current = pending.poll();
            if (current.equals(goal)) return true;
            for (Point neighbor : neighbors(current)) {
                if (!visited.contains(neighbor) && !obstacles.contains(neighbor) && !secondaryObstacles.contains(neighbor)) {
                    visited.add(neighbor);
                    pending.add(neighbor);
                }
            }
        }
        return false;
    }

    private void ensureKeyObstacles(Point start) {
        int obstacleCount = 0;
        for (Point n : neighbors(key)) {
            if (obstacles.contains(n)) obstacleCount++;
        }

        Set<Point> protectedAll = new HashSet<>();
        protectedAll.addAll(BANK_CELLS);
        protectedAll.addAll(J_CELLS);
        protectedAll.addAll(T_CELLS);

        List<Point> candidates = new ArrayList<>();
        for (Point n : neighbors(key)) {
            if (!obstacles.contains(n) && !secondaryObstacles.contains(n) && !protectedAll.contains(n)) {
                candidates.add(n);
            }
        }
        Collections.shuffle(candidates, random);

        for (Point candidate : candidates) {
            if (obstacleCount >= 2) break;
            obstacles.add(candidate);
            if (hasPath(start, key)) {
                obstacleCount++;
            } else {
                obstacles.remove(candidate);
            }
        }
    }

    private Point randomCell(Set<Point> cells) {
        List<Point> list = new ArrayList<>(cells);
        return list.get(random.nextInt(list.size()));
    }

    private List<Point> neighbors(Point cell) {
        List<Point> result = new ArrayList<>();
        for (int[] d : DIRECTIONS) {
            int nx = cell.x + d[0];
            int ny = cell.y + d[1];
            if (nx >= 1 && nx <= COLS && ny >= 1 && ny <= ROWS) {
                result.add(new Point(nx, ny));
            }
        }
        return result;
    }

    private void carvePath(Point start, Point goal) {
        Point current = new Point(start);
        while (!current.equals(goal)) {
            int x = current.x, y = current.y;
            int gx = goal.x, gy = goal.y;
            if (x != gx && (random.nextInt(2) == 0 || y == gy)) {
                current = new Point(x + (gx > x ? 1 : -1), y);
            } else {
                current = new Point(x, y + (gy > y ? 1 : -1));
            }
            obstacles.remove(current);
            secondaryObstacles.remove(current);
        }
    }

    // ===== 游戏流程 =====
    private void startGame(String role) {
        playerRole = role;
        player = randomCell(role.equals("T") ? T_CELLS : J_CELLS);
        robot = randomCell(role.equals("T") ? J_CELLS : T_CELLS);
        gameStarted = true;
        gameOver = false;
        turn = "T";
        roundNumber = 1;
        hasKey = false;
        robotHasKey = false;

        updateStatus();
        canvas.repaint();
        canvas.requestFocusInWindow();

        if (playerRole.equals("J")) {
            robotMove();
            turn = "J";
            canvas.repaint();
            updateStatus();
        }
    }

    private void handleKey(KeyEvent event) {
        if (!gameStarted || gameOver) return;
        String keyChar = KeyEvent.getKeyText(event.getKeyCode()).toLowerCase();
        if (!keyChar.equals("w") && !keyChar.equals("a") && !keyChar.equals("s") && !keyChar.equals("d")) return;
        if (!turn.equals(playerRole)) return;

        int dx = 0, dy = 0;
        switch (keyChar) {
            case "w": dy = -1; break;
            case "s": dy = 1; break;
            case "a": dx = -1; break;
            case "d": dx = 1; break;
        }

        Point target = new Point(player.x + dx, player.y + dy);
        if (canEnter(target) && !target.equals(robot)) {
            player = target;
            if (playerRole.equals("T") && player.equals(key)) {
                hasKey = true;
            }
            endPlayerTurn();
        }
    }

    private boolean canEnter(Point cell) {
        return cell.x >= 1 && cell.x <= COLS && cell.y >= 1 && cell.y <= ROWS
                && !obstacles.contains(cell) && !secondaryObstacles.contains(cell);
    }

    private void endPlayerTurn() {
        if (checkVictory()) return;

        turn = playerRole.equals("T") ? "J" : "T";
        robotMove();
        if (checkVictory()) return;

        turn = playerRole;
        roundNumber++;
        canvas.repaint();
        updateStatus();
    }

    private void robotMove() {
        if (playerRole.equals("T")) {
            robot = stepToward(robot, player, null);
        } else {
            Point target = !robotHasKey ? key : randomCell(BANK_CELLS);
            robot = stepToward(robot, target, player);
            if (robot.equals(key)) {
                robotHasKey = true;
            }
        }
    }

    private Point stepToward(Point start, Point target, Point avoid) {
        Queue<Object[]> pending = new LinkedList<>();
        Set<Point> visited = new HashSet<>();
        pending.add(new Object[]{start, null});
        visited.add(start);

        while (!pending.isEmpty()) {
            Object[] entry = pending.poll();
            Point current = (Point) entry[0];
            Point firstStep = (Point) entry[1];

            if (current.equals(target)) {
                return firstStep != null ? firstStep : start;
            }

            for (Point neighbor : neighbors(current)) {
                if (visited.contains(neighbor)) continue;
                if (avoid != null && neighbor.equals(avoid)) continue;
                if (!canEnter(neighbor)) continue;
                visited.add(neighbor);
                pending.add(new Object[]{neighbor, firstStep != null ? firstStep : neighbor});
            }
        }

        List<Point> choices = new ArrayList<>();
        for (Point cell : neighbors(start)) {
            if (canEnter(cell) && (avoid == null || !cell.equals(avoid))) {
                choices.add(cell);
            }
        }
        return choices.isEmpty() ? start : choices.get(random.nextInt(choices.size()));
    }

    private boolean checkVictory() {
        if (!gameStarted) return false;

        Point tPosition = playerRole.equals("J") ? robot : player;

        if (playerRole.equals("J")) {
            boolean robotInPlayerRange = neighbors3x3(player).contains(robot);
            boolean playerInRobotRange = neighbors3x3(tPosition).contains(player);
            if (robotInPlayerRange || playerInRobotRange) {
                finish("J 胜利：机器人进入了你的 3×3 范围，你获得了5M币！", true);
                return true;
            }
        } else if (hasKey && BANK_CELLS.contains(player) && !neighbors3x3(tPosition).contains(robot)) {
            finish("T 胜利：你拿到钥匙并到达了 BANK，你获得了5M币！", true);
            return true;
        }

        if (playerRole.equals("J") && robotHasKey) {
            if (BANK_CELLS.contains(robot) && !neighbors3x3(tPosition).contains(player)) {
                finish("T 胜利：机器人拿到钥匙并到达了 BANK。", false);
                return true;
            }
        }

        return false;
    }

    private Set<Point> neighbors3x3(Point center) {
        Set<Point> result = new HashSet<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int nx = center.x + dx;
                int ny = center.y + dy;
                if (nx >= 1 && nx <= COLS && ny >= 1 && ny <= ROWS) {
                    result.add(new Point(nx, ny));
                }
            }
        }
        return result;
    }

    private void finish(String message, boolean rewardPlayer) {
        gameOver = true;
        if (rewardPlayer) addReward();
        statusLabel.setText(message);
        JOptionPane.showMessageDialog(this, message, "游戏结束", JOptionPane.INFORMATION_MESSAGE);
    }

    @SuppressWarnings("unchecked")
    private void addReward() {
        try {
            File f = new File(DATA_FILE);
            if (!f.exists()) return;
            Object obj = SimpleJson.readFile(DATA_FILE);
            Map<String, Object> data = SimpleJson.asMap(obj);
            int current = SimpleJson.asInt(data.get("M币"), 0);
            data.put("M币", current + 5);
            SimpleJson.writeFile(DATA_FILE, data);
        } catch (Exception ignored) {}
    }

    private void updateStatus() {
        if (!gameStarted) return;
        String keyText = hasKey ? "已获得钥匙" : "未获得钥匙";
        statusLabel.setText("第 " + roundNumber + " 局 | 当前：" + turn + " | " + keyText + " | WASD 移动");
    }

    // ===== 游戏画布 =====
    private class GameCanvas extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            // 绘制格子
            for (int y = 1; y <= ROWS; y++) {
                for (int x = 1; x <= COLS; x++) {
                    Point cell = new Point(x, y);
                    int left = (x - 1) * CELL;
                    int top = (y - 1) * CELL;
                    boolean isObstacle = obstacles.contains(cell) || secondaryObstacles.contains(cell);
                    g2d.setColor(isObstacle ? Color.decode("#101010") : Color.WHITE);
                    g2d.fillRect(left, top, CELL, CELL);
                    g2d.setColor(Color.decode("#d9dfe3"));
                    g2d.drawRect(left, top, CELL, CELL);
                }
            }

            // 绘制保护区
            drawProtectedArea(g2d, BANK_CELLS, "BANK");
            drawProtectedArea(g2d, J_CELLS, "J");
            drawProtectedArea(g2d, T_CELLS, "T");

            // 绘制钥匙
            if (key != null) {
                int cx = (key.x - 1) * CELL + CELL / 2;
                int cy = (key.y - 1) * CELL + CELL / 2;
                g2d.setColor(Color.decode("#d4a017"));
                g2d.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 11));
                drawCenteredString(g2d, "🔑", cx, cy);
            }

            // 绘制角色
            drawCharacter(g2d, "T", playerRole != null && playerRole.equals("T") ? player : robot, "#e76f51");
            drawCharacter(g2d, "J", playerRole != null && playerRole.equals("J") ? player : robot, "#457b9d");
        }

        private void drawProtectedArea(Graphics2D g2d, Set<Point> cells, String label) {
            int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE;
            int maxX = 0, maxY = 0;
            for (Point p : cells) {
                minX = Math.min(minX, p.x);
                minY = Math.min(minY, p.y);
                maxX = Math.max(maxX, p.x);
                maxY = Math.max(maxY, p.y);
            }
            int x = (minX - 1) * CELL;
            int y = (minY - 1) * CELL;
            int w = (maxX - minX + 1) * CELL;
            int h = (maxY - minY + 1) * CELL;
            g2d.setColor(Color.BLACK);
            g2d.setStroke(new BasicStroke(2));
            g2d.drawRect(x, y, w, h);
            g2d.setStroke(new BasicStroke(1));

            g2d.setColor(Color.decode("#111111"));
            g2d.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 10));
            drawCenteredString(g2d, label, x + w / 2, y + h / 2);
        }

        private void drawCharacter(Graphics2D g2d, String role, Point pos, String colorHex) {
            if (pos == null) return;
            int cx = (pos.x - 1) * CELL + CELL / 2;
            int cy = (pos.y - 1) * CELL + CELL / 2;
            g2d.setColor(Color.decode(colorHex));
            g2d.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 11));
            drawCenteredString(g2d, role, cx, cy);
        }

        private void drawCenteredString(Graphics2D g2d, String text, int cx, int cy) {
            FontMetrics fm = g2d.getFontMetrics();
            int x = cx - fm.stringWidth(text) / 2;
            int y = cy - fm.getHeight() / 2 + fm.getAscent();
            g2d.drawString(text, x, y);
        }

        @Override
        public Dimension getPreferredSize() {
            return new Dimension(COLS * CELL, ROWS * CELL);
        }
    }

    // ===== 工具 =====
    private static JButton createGameButton(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 12));
        btn.setBackground(Color.decode("#2a9d8f"));
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setOpaque(true);
        btn.setBorder(BorderFactory.createEmptyBorder(6, 14, 6, 14));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode("#21867b"));
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode("#2a9d8f"));
            }
        });
        return btn;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JCZXT_world_easy app = new JCZXT_world_easy();
            app.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            app.setVisible(true);
        });
    }
}
