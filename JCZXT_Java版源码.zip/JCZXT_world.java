import javax.swing.*;
import java.awt.*;

/**
 * JCZXT 世界选择 —— Java 版
 * 对应 Python: JCZXT_world.py
 */
public class JCZXT_world extends JFrame {

    private JCZXT_world_easy easyWindow = null;

    public JCZXT_world() {
        setTitle("JCZXT 世界");
        setSize(700, 560);
        setMinimumSize(new Dimension(560, 420));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.decode("#f3f5f7"));

        // ===== 顶部栏 =====
        JPanel header = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 14));
        header.setBackground(Color.decode("#202b36"));
        JLabel titleLabel = new JLabel("JCZXT世界");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 20));
        header.add(titleLabel);
        root.add(header, BorderLayout.NORTH);

        // ===== 内容区 =====
        JPanel content = new JPanel();
        content.setBackground(Color.decode("#f3f5f7"));
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(24, 28, 24, 28));

        createOption(content, "简单", this::openEasy);
        for (String difficulty : new String[]{"普通", "困难", "噩梦"}) {
            createOption(content, difficulty, d -> notAvailable(d));
        }

        content.add(Box.createVerticalGlue());
        root.add(content, BorderLayout.CENTER);
        setContentPane(root);
    }

    private void createOption(JPanel parent, String difficulty, java.util.function.Consumer<String> command) {
        JPanel optionFrame = new JPanel();
        optionFrame.setOpaque(false);
        optionFrame.setMaximumSize(new Dimension(260, 58));
        optionFrame.setPreferredSize(new Dimension(260, 58));
        optionFrame.setLayout(new BorderLayout());
        optionFrame.setBorder(BorderFactory.createLineBorder(Color.decode("#111111"), 2));
        optionFrame.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton btn = new JButton(difficulty);
        btn.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 15));
        btn.setBackground(Color.decode("#f3f5f7"));
        btn.setForeground(Color.decode("#111111"));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setOpaque(true);
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode("#dce2e7"));
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent e) {
                btn.setBackground(Color.decode("#f3f5f7"));
            }
        });
        btn.addActionListener(e -> command.accept(difficulty));

        optionFrame.add(btn, BorderLayout.CENTER);
        parent.add(optionFrame);
        parent.add(Box.createVerticalStrut(8));
    }

    private void notAvailable(String difficulty) {
        JOptionPane.showMessageDialog(this, "“" + difficulty + "”世界还在开发中。",
                "提示", JOptionPane.INFORMATION_MESSAGE);
    }

    private void openEasy(String difficulty) {
        if (easyWindow != null && easyWindow.isDisplayable()) {
            easyWindow.toFront();
            easyWindow.requestFocus();
            return;
        }
        easyWindow = new JCZXT_world_easy();
        easyWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        easyWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                easyWindow = null;
            }
        });
        easyWindow.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JCZXT_world app = new JCZXT_world();
            app.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            app.setVisible(true);
        });
    }
}
