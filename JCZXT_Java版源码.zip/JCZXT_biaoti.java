import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * JCZXT 标题界面 —— Java 版
 * 对应 Python: JCZXT_biaoti.py
 * 主入口：运行此类启动游戏
 */
public class JCZXT_biaoti extends JFrame {

    private static final String DATA_FILE = "JCZXT_M.json";
    private static final int MAX_DETECTABLE_M = 1048576;

    private JCZXT_world worldWindow = null;
    private JCZXTshop shopWindow = null;
    private JCZXT_bag bagWindow = null;
    private int mCoins;

    public JCZXT_biaoti() {
        this.mCoins = loadMCoins();

        setTitle("JCZXT");
        setSize(700, 620);
        setMinimumSize(new Dimension(520, 480));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // ===== 根面板：BorderLayout =====
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.decode("#f4f1ea"));

        // ===== 顶部栏：版本号（左）+ M币（右）=====
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);
        topBar.setBorder(BorderFactory.createEmptyBorder(12, 14, 0, 14));

        JLabel versionLabel = new JLabel("JCZXT_26.1B");
        versionLabel.setForeground(Color.decode("#4b4b4b"));
        versionLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 10));
        topBar.add(versionLabel, BorderLayout.WEST);

        JLabel coinsLabel = new JLabel(mCoinsText());
        coinsLabel.setForeground(mCoins > MAX_DETECTABLE_M ? Color.decode("#b23a48") : Color.decode("#4b4b4b"));
        coinsLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 10));
        coinsLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        topBar.add(coinsLabel, BorderLayout.EAST);

        root.add(topBar, BorderLayout.NORTH);

        // ===== 中央内容区：垂直居中 =====
        JPanel centerWrapper = new JPanel(new GridBagLayout());
        centerWrapper.setOpaque(false);

        JPanel content = new JPanel();
        content.setOpaque(false);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        // 标题
        JLabel mainTitle = new JLabel("JCZXT");
        mainTitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainTitle.setForeground(Color.decode("#171717"));
        mainTitle.setFont(new Font("Microsoft YaHei UI", Font.BOLD, 48));
        content.add(mainTitle);

        content.add(Box.createVerticalStrut(8));

        // ★ 已从 PYTHON_EDITION 改为 JAVA EDITION ★
        JLabel editionLabel = new JLabel("JAVA EDITION");
        editionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        editionLabel.setForeground(Color.decode("#4b4b4b"));
        editionLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 24));
        content.add(editionLabel);

        content.add(Box.createVerticalStrut(40));

        // 菜单按钮
        createOption(content, "世界", this::openWorld, false);
        createOption(content, "商店", this::openShop, mCoins > MAX_DETECTABLE_M);
        createOption(content, "背包", this::openBag, false);

        centerWrapper.add(content);
        root.add(centerWrapper, BorderLayout.CENTER);

        // ===== 底部版权 =====
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 12));
        bottomBar.setOpaque(false);
        JLabel copyrightLabel = new JLabel("XGstudio.Co_@2026_By_XG\\HBK\\LJH\\_XAM");
        copyrightLabel.setForeground(Color.decode("#4b4b4b"));
        copyrightLabel.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 9));
        bottomBar.add(copyrightLabel);
        root.add(bottomBar, BorderLayout.SOUTH);

        setContentPane(root);
    }

    // ===== 数据 =====
    private int loadMCoins() {
        File f = new File(DATA_FILE);
        if (!f.exists()) {
            try {
                Map<String, Object> init = new LinkedHashMap<>();
                init.put("M币", 20);
                SimpleJson.writeFile(DATA_FILE, init);
            } catch (IOException ignored) {}
            return 20;
        }
        try {
            Object obj = SimpleJson.readFile(DATA_FILE);
            Map<String, Object> data = SimpleJson.asMap(obj);
            return SimpleJson.asInt(data.get("M币"), 0);
        } catch (Exception e) {
            return MAX_DETECTABLE_M + 1;
        }
    }

    private String mCoinsText() {
        if (mCoins > MAX_DETECTABLE_M) {
            return "M币：无法检测";
        }
        return "M币：" + mCoins;
    }

    // ===== 菜单按钮 =====
    private void createOption(JPanel parent, String text, Runnable command, boolean disabled) {
        JPanel optionFrame = new JPanel();
        optionFrame.setOpaque(false);
        optionFrame.setMaximumSize(new Dimension(260, 60));
        optionFrame.setPreferredSize(new Dimension(260, 60));
        optionFrame.setLayout(new BorderLayout());
        optionFrame.setBorder(BorderFactory.createLineBorder(Color.decode("#111111"), 2));
        optionFrame.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton btn = new JButton(text);
        btn.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 16));
        btn.setBackground(Color.decode("#f4f1ea"));
        btn.setForeground(Color.decode("#111111"));
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setContentAreaFilled(true);
        btn.setOpaque(true);
        btn.setEnabled(!disabled);

        if (!disabled) {
            btn.addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent e) {
                    btn.setBackground(Color.decode("#dedad1"));
                }
                @Override
                public void mouseExited(java.awt.event.MouseEvent e) {
                    btn.setBackground(Color.decode("#f4f1ea"));
                }
            });
            btn.addActionListener(e -> command.run());
        }

        optionFrame.add(btn, BorderLayout.CENTER);
        parent.add(optionFrame);
        parent.add(Box.createVerticalStrut(8));
    }

    // ===== 窗口管理 =====
    private void openWorld() {
        if (worldWindow != null && worldWindow.isDisplayable()) {
            worldWindow.toFront();
            worldWindow.requestFocus();
            return;
        }
        worldWindow = new JCZXT_world();
        worldWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        worldWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                worldWindow = null;
            }
        });
        worldWindow.setVisible(true);
    }

    private void openShop() {
        if (shopWindow != null && shopWindow.isDisplayable()) {
            shopWindow.toFront();
            shopWindow.requestFocus();
            return;
        }
        shopWindow = new JCZXTshop();
        shopWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        shopWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                shopWindow = null;
            }
        });
        shopWindow.setVisible(true);
    }

    private void openBag() {
        if (bagWindow != null && bagWindow.isDisplayable()) {
            bagWindow.toFront();
            bagWindow.requestFocus();
            return;
        }
        bagWindow = new JCZXT_bag();
        bagWindow.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        bagWindow.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosed(java.awt.event.WindowEvent e) {
                bagWindow = null;
            }
        });
        bagWindow.setVisible(true);
    }

    // ===== 主入口 =====
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JCZXT_biaoti app = new JCZXT_biaoti();
            app.setVisible(true);
        });
    }
}
